/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 didnotdraw did-not-draw.png 
 * Time-stamp: Tuesday 11/27/2018, 12:29:01
 * 
 * Image Information
 * -----------------
 * did-not-draw.png 240@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DIDNOTDRAW_H
#define DIDNOTDRAW_H

extern const unsigned short didnotdraw[1920];
#define DIDNOTDRAW_SIZE 3840
#define DIDNOTDRAW_LENGTH 1920
#define DIDNOTDRAW_WIDTH 240
#define DIDNOTDRAW_HEIGHT 8

#endif

