/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 snoopframes snoopframes.bmp 
 * Time-stamp: Tuesday 11/27/2018, 13:55:04
 * 
 * Image Information
 * -----------------
 * snoopframes.bmp 160@9600
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNOOPFRAMES_H
#define SNOOPFRAMES_H

extern const unsigned short snoopframes[1536000];
#define SNOOPFRAMES_SIZE 3072000
#define SNOOPFRAMES_LENGTH 1536000
#define SNOOPFRAMES_WIDTH 160
#define SNOOPFRAMES_HEIGHT 9600

#endif

