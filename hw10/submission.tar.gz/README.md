LEFT-ARROW: move left
RIGHT-ARROW: move right
X: jump
Z: shoot
ENTER: start game
SELECT: reset game

Instructions: The goal is to defeat the enemies to unlock the door. When all
enemies have been defeated, the door will turn green and you will be able to go
through it.

Notes:
There is a glitch in which the first shot fired turns Samus to the right.
