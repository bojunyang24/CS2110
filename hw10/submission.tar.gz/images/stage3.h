/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 stage3 stage3.png 
 * Time-stamp: Monday 11/19/2018, 07:48:43
 * 
 * Image Information
 * -----------------
 * stage3.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAGE3_H
#define STAGE3_H

extern const unsigned short stage3[38400];
#define STAGE3_SIZE 76800
#define STAGE3_LENGTH 38400
#define STAGE3_WIDTH 240
#define STAGE3_HEIGHT 160

#endif

