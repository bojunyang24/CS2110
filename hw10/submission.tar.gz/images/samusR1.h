/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusR1 samusR1.png 
 * Time-stamp: Monday 11/19/2018, 05:20:00
 * 
 * Image Information
 * -----------------
 * samusR1.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSR1_H
#define SAMUSR1_H

extern const unsigned short samusR1[500];
#define SAMUSR1_SIZE 1000
#define SAMUSR1_LENGTH 500
#define SAMUSR1_WIDTH 20
#define SAMUSR1_HEIGHT 25

#endif

