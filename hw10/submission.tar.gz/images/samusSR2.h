/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusSR2 samusSR2.png 
 * Time-stamp: Monday 11/19/2018, 21:44:08
 * 
 * Image Information
 * -----------------
 * samusSR2.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSSR2_H
#define SAMUSSR2_H

extern const unsigned short samusSR2[500];
#define SAMUSSR2_SIZE 1000
#define SAMUSSR2_LENGTH 500
#define SAMUSSR2_WIDTH 20
#define SAMUSSR2_HEIGHT 25

#endif

