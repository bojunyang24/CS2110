/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusSL5 samusSL5.png 
 * Time-stamp: Monday 11/19/2018, 08:49:28
 * 
 * Image Information
 * -----------------
 * samusSL5.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSSL5_H
#define SAMUSSL5_H

extern const unsigned short samusSL5[500];
#define SAMUSSL5_SIZE 1000
#define SAMUSSL5_LENGTH 500
#define SAMUSSL5_WIDTH 20
#define SAMUSSL5_HEIGHT 25

#endif

