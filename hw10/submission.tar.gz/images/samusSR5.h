/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusSR5 samusSR5.png 
 * Time-stamp: Monday 11/19/2018, 08:49:58
 * 
 * Image Information
 * -----------------
 * samusSR5.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSSR5_H
#define SAMUSSR5_H

extern const unsigned short samusSR5[500];
#define SAMUSSR5_SIZE 1000
#define SAMUSSR5_LENGTH 500
#define SAMUSSR5_WIDTH 20
#define SAMUSSR5_HEIGHT 25

#endif

