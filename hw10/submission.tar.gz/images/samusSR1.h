/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusSR1 samusSR1.png 
 * Time-stamp: Monday 11/19/2018, 08:49:42
 * 
 * Image Information
 * -----------------
 * samusSR1.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSSR1_H
#define SAMUSSR1_H

extern const unsigned short samusSR1[500];
#define SAMUSSR1_SIZE 1000
#define SAMUSSR1_LENGTH 500
#define SAMUSSR1_WIDTH 20
#define SAMUSSR1_HEIGHT 25

#endif

