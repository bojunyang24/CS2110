/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 stage3pass stage3pass.png 
 * Time-stamp: Tuesday 11/20/2018, 00:05:02
 * 
 * Image Information
 * -----------------
 * stage3pass.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAGE3PASS_H
#define STAGE3PASS_H

extern const unsigned short stage3pass[38400];
#define STAGE3PASS_SIZE 76800
#define STAGE3PASS_LENGTH 38400
#define STAGE3PASS_WIDTH 240
#define STAGE3PASS_HEIGHT 160

#endif

