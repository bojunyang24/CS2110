/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=18x18 orangecrawler orangecrawler.png 
 * Time-stamp: Monday 11/19/2018, 23:05:30
 * 
 * Image Information
 * -----------------
 * orangecrawler.png 18@18
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ORANGECRAWLER_H
#define ORANGECRAWLER_H

extern const unsigned short orangecrawler[324];
#define ORANGECRAWLER_SIZE 648
#define ORANGECRAWLER_LENGTH 324
#define ORANGECRAWLER_WIDTH 18
#define ORANGECRAWLER_HEIGHT 18

#endif

