/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 supermetroid supermetroid.jpg 
 * Time-stamp: Tuesday 11/20/2018, 00:45:40
 * 
 * Image Information
 * -----------------
 * supermetroid.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SUPERMETROID_H
#define SUPERMETROID_H

extern const unsigned short supermetroid[38400];
#define SUPERMETROID_SIZE 76800
#define SUPERMETROID_LENGTH 38400
#define SUPERMETROID_WIDTH 240
#define SUPERMETROID_HEIGHT 160

#endif

