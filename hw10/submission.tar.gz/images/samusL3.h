/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusL3 samusL3.png 
 * Time-stamp: Monday 11/19/2018, 05:01:14
 * 
 * Image Information
 * -----------------
 * samusL3.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSL3_H
#define SAMUSL3_H

extern const unsigned short samusL3[500];
#define SAMUSL3_SIZE 1000
#define SAMUSL3_LENGTH 500
#define SAMUSL3_WIDTH 20
#define SAMUSL3_HEIGHT 25

#endif

