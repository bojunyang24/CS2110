/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 stage4 stage4.png 
 * Time-stamp: Monday 11/19/2018, 07:48:51
 * 
 * Image Information
 * -----------------
 * stage4.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAGE4_H
#define STAGE4_H

extern const unsigned short stage4[38400];
#define STAGE4_SIZE 76800
#define STAGE4_LENGTH 38400
#define STAGE4_WIDTH 240
#define STAGE4_HEIGHT 160

#endif

