/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusL1 samusL1.png 
 * Time-stamp: Monday 11/19/2018, 03:11:37
 * 
 * Image Information
 * -----------------
 * samusL1.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSL1_H
#define SAMUSL1_H

extern const unsigned short samusL1[500];
#define SAMUSL1_SIZE 1000
#define SAMUSL1_LENGTH 500
#define SAMUSL1_WIDTH 20
#define SAMUSL1_HEIGHT 25

#endif

