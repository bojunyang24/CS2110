/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusR4 samusR4.png 
 * Time-stamp: Monday 11/19/2018, 05:20:15
 * 
 * Image Information
 * -----------------
 * samusR4.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSR4_H
#define SAMUSR4_H

extern const unsigned short samusR4[500];
#define SAMUSR4_SIZE 1000
#define SAMUSR4_LENGTH 500
#define SAMUSR4_WIDTH 20
#define SAMUSR4_HEIGHT 25

#endif

