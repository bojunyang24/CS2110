/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusR2 samusR2.png 
 * Time-stamp: Monday 11/19/2018, 05:20:05
 * 
 * Image Information
 * -----------------
 * samusR2.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSR2_H
#define SAMUSR2_H

extern const unsigned short samusR2[500];
#define SAMUSR2_SIZE 1000
#define SAMUSR2_LENGTH 500
#define SAMUSR2_WIDTH 20
#define SAMUSR2_HEIGHT 25

#endif

