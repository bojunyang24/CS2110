/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusSL2 samusSL2.png 
 * Time-stamp: Monday 11/19/2018, 08:49:11
 * 
 * Image Information
 * -----------------
 * samusSL2.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSSL2_H
#define SAMUSSL2_H

extern const unsigned short samusSL2[500];
#define SAMUSSL2_SIZE 1000
#define SAMUSSL2_LENGTH 500
#define SAMUSSL2_WIDTH 20
#define SAMUSSL2_HEIGHT 25

#endif

