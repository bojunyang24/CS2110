/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 stage1 stage1.png 
 * Time-stamp: Monday 11/19/2018, 03:00:38
 * 
 * Image Information
 * -----------------
 * stage1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAGE1_H
#define STAGE1_H

extern const unsigned short stage1[38400];
#define STAGE1_SIZE 76800
#define STAGE1_LENGTH 38400
#define STAGE1_WIDTH 240
#define STAGE1_HEIGHT 160

#endif

