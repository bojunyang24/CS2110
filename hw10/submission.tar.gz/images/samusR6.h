/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusR6 samusR6.png 
 * Time-stamp: Monday 11/19/2018, 05:20:23
 * 
 * Image Information
 * -----------------
 * samusR6.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSR6_H
#define SAMUSR6_H

extern const unsigned short samusR6[500];
#define SAMUSR6_SIZE 1000
#define SAMUSR6_LENGTH 500
#define SAMUSR6_WIDTH 20
#define SAMUSR6_HEIGHT 25

#endif

