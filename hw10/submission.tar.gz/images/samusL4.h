/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusL4 samusL4.png 
 * Time-stamp: Monday 11/19/2018, 05:01:18
 * 
 * Image Information
 * -----------------
 * samusL4.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSL4_H
#define SAMUSL4_H

extern const unsigned short samusL4[500];
#define SAMUSL4_SIZE 1000
#define SAMUSL4_LENGTH 500
#define SAMUSL4_WIDTH 20
#define SAMUSL4_HEIGHT 25

#endif

