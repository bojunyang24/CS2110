/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusSL4 samusSL4.png 
 * Time-stamp: Monday 11/19/2018, 08:49:23
 * 
 * Image Information
 * -----------------
 * samusSL4.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSSL4_H
#define SAMUSSL4_H

extern const unsigned short samusSL4[500];
#define SAMUSSL4_SIZE 1000
#define SAMUSSL4_LENGTH 500
#define SAMUSSL4_WIDTH 20
#define SAMUSSL4_HEIGHT 25

#endif

