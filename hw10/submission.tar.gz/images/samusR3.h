/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x25 samusR3 samusR3.png 
 * Time-stamp: Monday 11/19/2018, 05:20:10
 * 
 * Image Information
 * -----------------
 * samusR3.png 20@25
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSR3_H
#define SAMUSR3_H

extern const unsigned short samusR3[500];
#define SAMUSR3_SIZE 1000
#define SAMUSR3_LENGTH 500
#define SAMUSR3_WIDTH 20
#define SAMUSR3_HEIGHT 25

#endif

