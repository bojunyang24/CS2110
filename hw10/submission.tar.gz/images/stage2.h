/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 stage2 stage2.png 
 * Time-stamp: Monday 11/19/2018, 07:19:14
 * 
 * Image Information
 * -----------------
 * stage2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAGE2_H
#define STAGE2_H

extern const unsigned short stage2[38400];
#define STAGE2_SIZE 76800
#define STAGE2_LENGTH 38400
#define STAGE2_WIDTH 240
#define STAGE2_HEIGHT 160

#endif

